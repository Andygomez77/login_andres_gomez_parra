package com.example.login_andres_gomez;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ActivityResultado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);
    }
}

