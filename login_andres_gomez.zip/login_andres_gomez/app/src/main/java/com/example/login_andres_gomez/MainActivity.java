package com.example.login_andres_gomez;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsuario, editTextContraseña;
    private Button buttonIngresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextUsuario = findViewById(R.id.usuario);
        editTextContraseña = findViewById(R.id.contraseña);
        buttonIngresar = findViewById(R.id.ingresar);


        buttonIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarLogin();
            }
        });
    }


    private void validarLogin() {
        String usuario = editTextUsuario.getText().toString().trim();
        String contraseña = editTextContraseña.getText().toString().trim();


        if (usuario.isEmpty() || contraseña.isEmpty()) {
            Toast.makeText(MainActivity.this, "Por favor llenar los campos", Toast.LENGTH_SHORT).show();
        }

        else if (usuario.equals("uac123") && contraseña.equals("12345678")) {

            Intent intent = new Intent(MainActivity.this, ActivityResultado.class);
            startActivity(intent);
        }

        else {
            Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
        }
    }
}
